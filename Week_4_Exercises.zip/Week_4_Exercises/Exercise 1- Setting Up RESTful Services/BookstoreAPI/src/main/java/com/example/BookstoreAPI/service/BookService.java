package com.example.BookstoreAPI.service;

import com.example.BookstoreAPI.entity.Book;
import com.example.BookstoreAPI.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Service
public class BookService {

    @Autowired
    private BookRepository bookRepository;

    public List<Book> getAllBooks() {
        return bookRepository.findAll();
    }

    public Book getBookById(Long id) {
        return bookRepository.findById(id).orElse(null);
    }

    public Book addBook(Book book) {
        return bookRepository.save(book);
    }

    public Book updateBook(Long id, Book bookDetails) {
        Book book = bookRepository.findById(id).orElse(null);
        if (book != null) {
            book.setTitle(bookDetaiimport java.util.List;

            @RestController
            @RequestMapping("/api/books")
            public class BookController {

                @Autowired
                private BookService bookService;

                @GetMapping
                public List<Book> getAllBooks() {
                    return bookService.getAllBooks();
                }

                @GetMapping("/{id}")
                public Book getBookById(@PathVariable Long id) {
                    return bookService.getBookById(id);
                }

                @PostMapping
                public Book addBook(@RequestBody Book book) {
                    return bookService.addBook(book);
                }

                @PutMapping("/{id}")
                public Book updateBook(@PathVariable Long id, @RequestBody Book bookDetails) {
                    return bookService.updateBook(id, bookDetails);
                }

                @DeleteMapping("/{id}")
                public void deleteBook(@PathVariable Long id) {
                    bookService.deleteBook(id);
                }
            }ls.getTitle());
            book.setAuthor(bookDetails.getAuthor());
            book.setPrice(bookDetails.getPrice());
            return bookRepository.save(book);
        }
        return null;
    }

    public void deleteBook(Long id) {
        bookRepository.deleteById(id);
    }
}
