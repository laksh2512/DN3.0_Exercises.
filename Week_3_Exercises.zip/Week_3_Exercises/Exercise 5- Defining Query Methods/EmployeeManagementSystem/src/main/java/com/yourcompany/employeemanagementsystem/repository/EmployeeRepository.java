package com.yourcompany.employeemanagementsystem.repository;

import com.yourcompany.employeemanagementsystem.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Query(name = "Employee.findByDepartment")
    List<Employee> findByDepartment(Long departmentId);

    @Query(name = "Employee.countBySalaryGreaterThan")
    long countBySalaryGreaterThan(Double salary);
}
