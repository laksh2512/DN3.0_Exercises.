package com.yourcompany.employeemanagementsystem.projection;

import org.springframework.beans.factory.annotation.Value;

public class EmployeeInfo {
    private String employeeName;
    private String departmentName;

    public EmployeeInfo(String employeeName, String departmentName) {
        this.employeeName = employeeName;
        this.departmentName = departmentName;
    }

    @Value("#{target.employeeName} #{target.departmentName}")
    public String getEmployeeInfo() {
        return this.employeeName + " works in " + this.departmentName + " department.";
    }

    // Getters
    public String getEmployeeName() {
        return employeeName;
    }

    public String getDepartmentName() {
        return departmentName;
    }
}
