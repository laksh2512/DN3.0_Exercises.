package com.yourcompany.employeemanagementsystem;

import com.yourcompany.employeemanagementsystem.entity.Department;
import com.yourcompany.employeemanagementsystem.entity.Employee;
import com.yourcompany.employeemanagementsystem.repository.DepartmentRepository;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public void run(String... args) throws Exception {
        Department department = new Department();
        department.setName("HR");

        department = departmentRepository.save(department);

        Employee employee = new Employee();
        employee.setName("John Doe");
        employee.setEmail("john.doe@example.com");
        employee.setDepartment(department);

        employeeRepository.save(employee);
    }
}
