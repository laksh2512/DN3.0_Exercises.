package com.yourcompany.employeemanagementsystem.service;

import com.yourcompany.employeemanagementsystem.model.Employee;
import com.yourcompany.employeemanagementsystem.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepository;

    // Retrieve all employees
    public List<Employee> findAll() {
        return employeeRepository.findAll();
    }

    // Retrieve employee by ID
    public Employee findById(Long id) {
        Optional<Employee> employee = employeeRepository.findById(id);
        return employee.orElse(null); // Or throw a custom exception if preferred
    }

    // Save or update an employee
    public Employee save(Employee employee) {
        return employeeRepository.save(employee);
    }

    // Delete employee by ID
    public void deleteById(Long id) {
        employeeRepository.deleteById(id);
    }
}
