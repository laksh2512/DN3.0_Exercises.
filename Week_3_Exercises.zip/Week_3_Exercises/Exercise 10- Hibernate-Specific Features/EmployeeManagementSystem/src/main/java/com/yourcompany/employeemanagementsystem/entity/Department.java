package com.example.employee.entity;

import org.hibernate.annotations.BatchSize;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "departments")
@BatchSize(size = 10)
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @OneToMany(mappedBy = "department", fetch = FetchType.LAZY)
    private List<Employee> employees;

    // Getters and setters
}
