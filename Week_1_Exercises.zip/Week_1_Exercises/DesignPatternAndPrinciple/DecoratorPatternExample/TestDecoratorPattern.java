package DecoratorPatternExample;

// TestDecoratorPattern.java
public class TestDecoratorPattern {
    public static void main(String[] args) {
        Notifier notifier = new EmailNotifier();
        notifier.send("Hello, World!");

        System.out.println("\nAdding SMS Notifier:");
        Notifier smsNotifier = new SMSNotifierDecorator(notifier);
        smsNotifier.send("Hello, World!");

        System.out.println("\nAdding Slack Notifier:");
        Notifier slackNotifier = new SlackNotifierDecorator(smsNotifier);
        slackNotifier.send("Hello, World!");
    }
}

