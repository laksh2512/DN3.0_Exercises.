package BuilderPatterExample;

public class Computer {
    // Required parameters
    private final String cpu;
    private final String ram;

    private final String storage;
    private final String gpu;
    private Computer(Builder builder) {
        this.cpu = builder.cpu;
        this.ram = builder.ram;
        this.storage = builder.storage;
        this.gpu = builder.gpu;
    }
    public String getCpu() {
        return cpu;
    }

    public String getRam() {
        return ram;
    }

    public String getStorage() {
        return storage;
    }

    public String getGpu() {
        return gpu;
    }

    @Override
    public String toString() {
        return "Computer{" +
                "CPU='" + cpu + '\'' +
                ", RAM='" + ram + '\'' +
                ", Storage='" + storage + '\'' +
                ", GPU='" + gpu + '\'' +
                '}';
    }

    public static class Builder {
        private final String cpu;
        private final String ram;

        private String storage = "500GB HDD";
        private String gpu = "NVIDIA GTX 1650";

        public Builder(String cpu, String ram) {
            if (cpu == null || cpu.isEmpty()) {
                throw new IllegalArgumentException("CPU cannot be null or empty");
            }
            if (ram == null || ram.isEmpty()) {
                throw new IllegalArgumentException("RAM cannot be null or empty");
            }
            this.cpu = cpu;
            this.ram = ram;
        }

        public Builder storage(String storage) {
            this.storage = storage;
            return this;
        }

        public Builder gpu(String gpu) {
            this.gpu = gpu;
            return this;
        }

        public Computer build() {
            return new Computer(this);
        }
    }

    public static class TestComputerBuilder {
        public static void main(String[] args) {
            Computer computer1 = new Computer.Builder("Intel i7", "16GB")
                    .storage("1TB SSD")
                    .gpu("NVIDIA RTX 3060")
                    .build();

            Computer computer2 = new Computer.Builder("AMD Ryzen 5", "8GB")
                    .build();

            System.out.println(computer1);
            System.out.println(computer2);
        }
    }
}

