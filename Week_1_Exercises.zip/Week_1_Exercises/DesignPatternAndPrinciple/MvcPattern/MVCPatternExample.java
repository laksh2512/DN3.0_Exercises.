package MvcPattern;

public class MVCPatternExample {
    public static void main(String[] args) {
        // Create a new student
        Student model = new Student("John Doe", "1234", "A");

        // Create a view to display student details
        StudentView view = new StudentView();

        // Create a controller to manage the model and view
        StudentController controller = new StudentController(model, view);

        // Update the view to display the initial student details
        controller.updateView();

        // Update the model with new data
        controller.setStudentName("Jane Doe");
        controller.setStudentId("5678");
        controller.setStudentGrade("B");

        // Update the view to display the updated student details
        controller.updateView();
    }
}

