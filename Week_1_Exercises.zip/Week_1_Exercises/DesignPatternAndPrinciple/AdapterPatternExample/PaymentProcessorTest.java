package AdapterPatternExample;

public class PaymentProcessorTest {
    public static void main(String[] args) {
        // Create instances of payment gateways
        PayPalGateway payPalGateway = new PayPalGateway();
        StripeGateway stripeGateway = new StripeGateway();

        // Create adapters for payment gateways
        PaymentProcessor payPalAdapter = new PayPalAdapter(payPalGateway);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripeGateway);

        // Process payments using adapters
        payPalAdapter.processPayment("Payment details for PayPal");
        stripeAdapter.processPayment("Payment details for Stripe");
    }
}
