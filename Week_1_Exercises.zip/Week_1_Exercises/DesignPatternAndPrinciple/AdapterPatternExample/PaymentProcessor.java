package AdapterPatternExample;

public interface PaymentProcessor {
    void processPayment(String paymentDetails);
}
