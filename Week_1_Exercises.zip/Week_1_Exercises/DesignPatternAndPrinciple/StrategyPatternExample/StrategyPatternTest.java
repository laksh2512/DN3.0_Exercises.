package StrategyPatternExample;

public class StrategyPatternTest {
    public static void main(String[] args) {
        PaymentContext paymentContext = new PaymentContext(null);

        // Paying with Credit Card
        PaymentStrategy creditCardPayment = new CreditCardPayment("1234-5678-9101-1121", "John Doe");
        paymentContext.setPaymentStrategy(creditCardPayment);
        paymentContext.pay(100.0);

        // Paying with PayPal
        PaymentStrategy payPalPayment = new PayPalPayment("johndoe@example.com");
        paymentContext.setPaymentStrategy(payPalPayment);
        paymentContext.pay(150.0);
    }
}

