package FactoryMethodPatternExample;

public interface DocumentFactory {
    Document createDocument();
}

