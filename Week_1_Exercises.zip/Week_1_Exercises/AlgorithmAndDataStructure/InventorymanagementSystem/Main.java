package InventorymanagementSystem;

public class Main {
    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();
        Product p1 = new Product("001", "Laptop", 10, 799.99);
        Product p2 = new Product("002", "Smartphone", 25, 399.99);
        Product p3 = new Product("003", "Tablet", 15, 199.99);
        ims.addProduct(p1);
        ims.addProduct(p2);
        ims.addProduct(p3);
        System.out.println("All products:");
        ims.displayAllProducts();
        Product p2Updated = new Product("002", "Smartphone", 20, 379.99);
        ims.updateProduct("002", p2Updated);
        System.out.println("\nProducts after update:");
        ims.displayAllProducts();
        ims.deleteProduct("003");
        System.out.println("\nProducts after deletion:");
        ims.displayAllProducts();
        Product p = ims.getProduct("001");
        System.out.println("\nRetrieved product:");
        System.out.println(p);
    }
}
