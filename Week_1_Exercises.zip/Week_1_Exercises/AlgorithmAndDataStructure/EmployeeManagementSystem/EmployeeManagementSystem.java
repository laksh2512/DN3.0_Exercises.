package EmployeeManagementSystem;

import java.util.Arrays;

public class EmployeeManagementSystem {
    private Employee[] employees;
    private int size;

    public EmployeeManagementSystem(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }
    public boolean addEmployee(Employee employee) {
        if (size >= employees.length) {
            return false;
        }
        employees[size++] = employee;
        return true;
    }
    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].employeeId == employeeId) {
                return employees[i];
            }
        }
        return null;
    }
    public void traverseEmployees() {
        for (int i = 0; i < size; i++) {
            System.out.println(employees[i]);
        }
    }
    public boolean deleteEmployee(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].employeeId == employeeId) {
                // Shift elements to the left
                for (int j = i; j < size - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[--size] = null;
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(10);
        ems.addEmployee(new Employee(1, "Alice", "Manager", 50000));
        ems.addEmployee(new Employee(2, "Bob", "Developer", 40000));
        ems.addEmployee(new Employee(3, "Charlie", "Analyst", 45000));
        System.out.println("All Employees:");
        ems.traverseEmployees();
        System.out.println("\nSearch Employee with ID 2:");
        System.out.println(ems.searchEmployee(2));
        System.out.println("\nDelete Employee with ID 2:");
        ems.deleteEmployee(2);
        System.out.println("\nAll Employees after deletion:");
        ems.traverseEmployees();
    }
}

