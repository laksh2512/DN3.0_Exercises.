package EcommercePlatform;
import  java.util.*;
public class SearchDemo {
    public static void main(String[] args) {
        Product[] products = {
                new Product(1, "Laptop", "Electronics"),
                new Product(2, "Smartphone", "Electronics"),
                new Product(3, "Book", "Books")
        };
        Product foundProduct = LinearSearch.linearSearch(products, 2);
        System.out.println("Linear Search Result: " + (foundProduct != null ? foundProduct : "Not found"));

        Arrays.sort(products, (p1, p2) -> Integer.compare(p1.getProductId(), p2.getProductId()));
        foundProduct = BinarySearch.binarySearch(products, 2);
        System.out.println("Binary Search Result: " + (foundProduct != null ? foundProduct : "Not found"));
    }
}

