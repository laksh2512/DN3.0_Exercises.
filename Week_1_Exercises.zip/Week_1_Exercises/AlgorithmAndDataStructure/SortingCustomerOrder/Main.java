package SortingCustomerOrder;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        Order[] orders = {
                new Order(1, "Alice", 300.50),
                new Order(2, "Bob", 150.75),
                new Order(3, "Charlie", 450.00),
                new Order(4, "David", 200.25),
                new Order(5, "Eve", 100.00)
        };


        System.out.println("Original Orders:");
        printOrders(orders);


        Order[] bubbleSortedOrders = Arrays.copyOf(orders, orders.length);
        BubbleSort.bubbleSort(bubbleSortedOrders);
        System.out.println("\nOrders Sorted by Bubble Sort:");
        printOrders(bubbleSortedOrders);


        Order[] quickSortedOrders = Arrays.copyOf(orders, orders.length);
        QuickSort.quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);
        System.out.println("\nOrders Sorted by Quick Sort:");
        printOrders(quickSortedOrders);
    }

    private static void printOrders(Order[] orders) {
        for (Order order : orders) {
            System.out.println("Order ID: " + order.getOrderId() +
                    ", Customer Name: " + order.getCustomerName() +
                    ", Total Price: " + order.getTotalPrice());
        }
    }
}

