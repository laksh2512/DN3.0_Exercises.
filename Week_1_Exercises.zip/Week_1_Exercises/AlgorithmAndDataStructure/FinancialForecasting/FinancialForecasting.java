package FinancialForecasting;

//time complexity of your recursive algorithm.
public class FinancialForecasting {

    public static double futureValue(double initialValue, double growthRate, int years) {
        if (years == 0) {
            return initialValue;
        }
        return futureValue(initialValue * (1 + growthRate), growthRate, years - 1);
    }

    public static void main(String[] args) {
        double initialValue = 1000;
        double growthRate = 0.05;
        int years = 10;
        double futureVal = futureValue(initialValue, growthRate, years);
        System.out.println("The future value of the investment is: $" + futureVal);
    }
}

