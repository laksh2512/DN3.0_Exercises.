package com.library.repository;

public class BookRepository {
}
